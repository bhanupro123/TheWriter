import React from 'react';
 
import {
    SafeAreaView,
    ScrollView,
    StatusBar,
    StyleSheet,
    Text,
    useColorScheme,
    View,Image
} from 'react-native';
import LogoBackground from './LogoBackground';
 
const SignUp = () => {
    return (
        <LogoBackground>
             
        </LogoBackground>
    );
};



export default SignUp;