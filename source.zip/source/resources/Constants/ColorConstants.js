const ColorConstants={
    baseColor:"#fef4e8",
    baseBlueColor:"#003f7d",
    baseOrangeColor:"#fd7702",
    red:"red",
    white:"white",
}

export default ColorConstants;