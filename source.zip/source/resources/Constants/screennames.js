const ScreenNames={
    SPLASH:"splash",LoginSignUp:"loginSignUp",Welcome:"Welcome",LogoBackground:"LogoBackground",LogIn:"LogIn",SignUp:"SignUp",Verify:"Verify",ModeSelection:"ModeSelection",KnownLanguages:"KnownLanguages"
    }
    
    export default ScreenNames;