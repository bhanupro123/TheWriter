const ValueConstants={
    DELAY_ONPRESS:2000
}

export default ValueConstants;