const StringConstants={
    LOGIN:"Login",
    SIGNUP:"Sign Up",
    Proceed:"Proceed",
    SignIn_to_access_your_account:"Sign in to access your account!",
    Welcome:"Welcome",
    Verify_your_number:"verifiying your phone number !",
    Verify:"Verify"
}

export default StringConstants;