const ImageWrapper={
thewriter:require("../images/thewriter.png")

}
 
export default ImageWrapper;